﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SlowUnitTestsOneAssembly
{
  [TestClass]
  public class UnitTests01to10
  {
    [TestMethod]
    public void SlowUnitTest01()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest02()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest03()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest04()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest05()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTest06()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest07()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest08()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest09()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest10()
    {
      System.Threading.Thread.Sleep(1000);
    }
  }
  [TestClass]
  public class UnitTests11to20
  {
    [TestMethod]
    public void SlowUnitTest11()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest12()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest13()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest14()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest15()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest16()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest17()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest18()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest19()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest20()
    {
      System.Threading.Thread.Sleep(1000);
    }
  }
  [TestClass]
  public class UnitTests21to30
  {
    [TestMethod]
    public void SlowUnitTest21()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest22()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest23()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest24()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest25()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest26()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest27()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest28()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest29()
    {
      System.Threading.Thread.Sleep(1000);
    }
    [TestMethod]
    public void SlowUnitTest30()
    {
      System.Threading.Thread.Sleep(1000);
    }
  }
}
