﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SlowUnitTests
{
  [TestClass]
  public class UnitTests
  {

    [TestMethod]
    public void SlowUnitTestB01()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestB02()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestB03()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestB04()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestB05()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestB06()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestB07()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestB08()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestB09()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestB10()
    {
      System.Threading.Thread.Sleep(1000);
    }
  }
}
