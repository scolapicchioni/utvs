﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SlowUnitTests
{
  [TestClass]
  public class UnitTests
  {

    [TestMethod]
    public void SlowUnitTestC01()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC02()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC03()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC04()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC05()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC06()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC07()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC08()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC09()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC10()
    {
      System.Threading.Thread.Sleep(1000);
    }
  }
}
