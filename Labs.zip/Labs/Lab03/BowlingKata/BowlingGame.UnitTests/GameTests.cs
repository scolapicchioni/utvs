using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingGame.UnitTests
{
  [TestClass]
  public class GameTests
  {

  }
}
